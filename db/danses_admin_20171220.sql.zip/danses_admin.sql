-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 20 Décembre 2017 à 08:43
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `danses_admin`
--

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation` varchar(255) DEFAULT NULL,
  `fonction` varchar(255) DEFAULT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(30) DEFAULT NULL,
  `commentaires` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `contact`
--

INSERT INTO `contact` (`id`, `organisation`, `fonction`, `nom`, `prenom`, `email`, `telephone`, `commentaires`) VALUES
(1, 'Firme', 'DG', 'Test', 'Pre', 'tes@mail.com', '+33644556688', 'Com');

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

CREATE TABLE IF NOT EXISTS `cours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `id_groupe` int(11) NOT NULL,
  `danses` text,
  `commentaires` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `cours`
--

INSERT INTO `cours` (`id`, `date`, `id_groupe`, `danses`, `commentaires`) VALUES
(1, '2017-11-26', 4, 'Ksesyrtos\r\nMpgdanos / Milisso\r\nTsestos', 'Marina a montrée des danses d''Epire\r\nDimitri Manolis a montré Selanik'),
(2, '0000-00-00', 0, '', ''),
(3, '2017-12-10', 4, '', ''),
(4, '2017-12-10', 2, '', ''),
(5, '2017-12-10', 5, '', '');

-- --------------------------------------------------------

--
-- Structure de la table `cours_presences`
--

CREATE TABLE IF NOT EXISTS `cours_presences` (
  `id_cours` int(11) NOT NULL,
  `id_profile` int(11) NOT NULL,
  PRIMARY KEY (`id_cours`,`id_profile`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `cours_presences`
--

INSERT INTO `cours_presences` (`id_cours`, `id_profile`) VALUES
(0, 8),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(3, 8),
(3, 9),
(3, 10),
(3, 12),
(4, 9),
(5, 8),
(5, 9),
(5, 10),
(5, 12);

-- --------------------------------------------------------

--
-- Structure de la table `evenement`
--

CREATE TABLE IF NOT EXISTS `evenement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date DEFAULT NULL,
  `description` text,
  `lieu` varchar(255) DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `code_postal` varchar(5) DEFAULT NULL,
  `ville` varchar(255) DEFAULT NULL,
  `pays` varchar(255) DEFAULT NULL,
  `nombre_danseurs` int(11) DEFAULT NULL,
  `programme` text,
  `type` int(11) NOT NULL,
  `costumes` text,
  `id_prof` int(11) DEFAULT NULL,
  `id_contact` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `evenement`
--

INSERT INTO `evenement` (`id`, `titre`, `date_debut`, `date_fin`, `description`, `lieu`, `adresse`, `code_postal`, `ville`, `pays`, `nombre_danseurs`, `programme`, `type`, `costumes`, `id_prof`, `id_contact`) VALUES
(3, 'Fête des Forces Armées Helléniques', '2017-11-21', '0000-00-00', 'Représentation à l''ambassage de Grèce pour la fête des Forces Armées Helléniques', 'Ambassade de Grèce', '17 Rue Auguste Vacquerie', '75116', 'Paris', 'France', 7, 'Anogianos Pidichtos\r\nMaleviziotis\r\nSyrtos Chaniotikos\r\nPentozalis', 1, 'Crète', 8, 1);

-- --------------------------------------------------------

--
-- Structure de la table `event_participation`
--

CREATE TABLE IF NOT EXISTS `event_participation` (
  `id_event` int(11) NOT NULL,
  `id_profile` int(11) NOT NULL,
  PRIMARY KEY (`id_event`,`id_profile`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `event_participation`
--

INSERT INTO `event_participation` (`id_event`, `id_profile`) VALUES
(3, 8),
(3, 10),
(3, 11),
(3, 13);

-- --------------------------------------------------------

--
-- Structure de la table `groupes`
--

CREATE TABLE IF NOT EXISTS `groupes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `heure_debut` time DEFAULT NULL,
  `heure_fin` time DEFAULT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `code_postal` varchar(5) DEFAULT NULL,
  `ville` varchar(255) DEFAULT NULL,
  `jour` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `groupes`
--

INSERT INTO `groupes` (`id`, `nom`, `heure_debut`, `heure_fin`, `adresse`, `code_postal`, `ville`, `jour`) VALUES
(1, 'Débutants', '15:00:00', '16:00:00', '14 passage du genie', '75012', 'Paris', 'dimanche'),
(2, 'Intermédiaires', '17:00:00', '18:00:00', '2 bis rue laférière', '75009', 'Paris', 'Dimanche'),
(4, 'Confirmés', '18:00:00', '20:00:00', '2 bis rue laférière', '75009', 'Paris', 'Dimanche'),
(5, 'Chant', '16:00:00', '17:00:00', '2 bis rue laférière', '75009', 'Paris', 'Dimanche');

-- --------------------------------------------------------

--
-- Structure de la table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `date_naissance` date DEFAULT NULL,
  `date_arrivee` date DEFAULT NULL,
  `date_depart` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telephone` varchar(15) DEFAULT NULL,
  `code_postal` varchar(5) DEFAULT NULL,
  `ville` varchar(255) DEFAULT NULL,
  `pays` varchar(255) DEFAULT NULL,
  `pointure` int(11) DEFAULT NULL,
  `taille` int(11) DEFAULT NULL,
  `professeur` tinyint(1) NOT NULL DEFAULT '0',
  `id_groupe_prof` int(11) DEFAULT NULL,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `adresse` varchar(255) DEFAULT NULL,
  `commentaire` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Contenu de la table `profile`
--

INSERT INTO `profile` (`id`, `nom`, `prenom`, `date_naissance`, `date_arrivee`, `date_depart`, `email`, `telephone`, `code_postal`, `ville`, `pays`, `pointure`, `taille`, `professeur`, `id_groupe_prof`, `date_creation`, `date_modification`, `adresse`, `commentaire`) VALUES
(8, 'Paparas', 'Constantinos', '1981-07-15', '1990-09-10', '0000-00-00', 'costapaparas.danse@gmail.com', '+33 6 26 31 98 ', '95120', 'Ermont', 'France', 43, 186, 1, 1, '2017-11-23 11:46:10', '2017-12-13 13:37:21', '8 rue des écoles', 'Test'),
(9, 'Melodias', 'Nicolas', '1989-01-30', '2006-09-11', '0000-00-00', 'nicolasmelodias.danse@gmail.com', '', '75012', 'Paris', 'France', 0, 0, 1, 2, '2017-11-30 11:06:14', '2017-12-12 12:23:29', '2 passage du génie', ''),
(10, 'Alexopoulos', 'Daphné', '1988-03-25', '2003-09-10', '0000-00-00', 'daphnealexopoulos.danse@gmail.com', '', '95120', 'Ermont', 'France', 0, 0, 1, 5, '2017-11-30 11:08:54', '2017-11-30 11:08:54', '8 rue des écoles', ''),
(11, 'Mélodias', 'Mélanie', '1987-12-20', '0000-00-00', '0000-00-00', 'melaniemelodias.danse@gmail.com', '', '', '', '', 0, 0, 1, 2, '2017-11-30 11:10:48', '2017-11-30 11:10:48', '', ''),
(12, 'Andréadis', 'Alexis', '1985-09-10', '0000-00-00', '0000-00-00', 'aa.lykionparis@gmail.com', '', '', '', '', 0, 0, 1, 4, '2017-11-30 11:12:06', '2017-11-30 11:12:06', '', ''),
(13, 'Lucas', 'Dimitri', '1983-04-27', '1990-09-10', '0000-00-00', 'dl.lykionparis@gmail.com', '', '', '', '', 0, 0, 1, 1, '2017-11-30 11:12:54', '2017-12-13 13:37:29', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `profile_groupes`
--

CREATE TABLE IF NOT EXISTS `profile_groupes` (
  `id_profile` int(11) NOT NULL,
  `id_groupe` int(11) NOT NULL,
  PRIMARY KEY (`id_profile`,`id_groupe`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `profile_groupes`
--

INSERT INTO `profile_groupes` (`id_profile`, `id_groupe`) VALUES
(8, 1),
(8, 4),
(8, 5),
(9, 2),
(9, 4),
(9, 5),
(10, 4),
(10, 5),
(11, 4),
(11, 5),
(12, 4),
(12, 5),
(13, 1),
(13, 4),
(13, 5);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`username`, `password`) VALUES
('admin', 'fcde988b6e60b4ae4731dd9d4000b531'),
('cpaparas', '9537daca0778d4513ca5c74f298b61d9');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
